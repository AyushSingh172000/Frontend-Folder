import React from "react";
import style from "./navbar.module.css";
import { Link } from "react-router-dom";
const Navbar = () => {
  return (
    <nav id={style.nav}>
      <figure>
        <img src="/hive.png" alt="hive-logo" title="hive" />
      </figure>
      <ul>
        <li>
          <Link to="/">home</Link>
        </li>

        <li className="primary-btn login-btn">
          <Link to="/login">login</Link>
        </li>

        <li className="secondary-btn">
          <Link to="/signup">signup</Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
